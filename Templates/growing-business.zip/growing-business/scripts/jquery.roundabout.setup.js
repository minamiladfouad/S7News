$(document).ready(function () {
    $('.roundabout-holder').roundabout({
        minOpacity: 0.5,
        maxOpacity: 1.0,
        minScale: 0.5,
        maxScale: 1.0,
		shape: 'lazySusan'
    });
});
